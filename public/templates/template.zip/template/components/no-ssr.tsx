
export const NoSSR = ({ children }: { children: React.ReactNode }) => {
  return <>{children}</>;
}