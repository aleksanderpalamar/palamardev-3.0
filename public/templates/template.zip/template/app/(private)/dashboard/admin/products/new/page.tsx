import { NewProductForm } from "@/components/newproduct-form";

export default function NewProduct() {
  return <NewProductForm />
}